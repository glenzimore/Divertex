<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Form</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Roboto:wght@400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="applicationform.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Divertex</h1>
            <p class="tagline">Join our team and make a difference!</p>
        </div>
        <div class="contact-form" id="applicationForm">
            <h2>Application Form</h2>
            <form id="form" method="POST" action="submit_application.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Full Name:</label>
                    <input type="text" id="name" name="name" placeholder="Ex. Juan Dela Cruz" required>
                </div>

                <div class="form-group">
                    <label for="sex">Sex:</label>
                    <select id="sex" name="sex" style="width: 300px; height:28px;" required>
                        <option value="" disabled selected>Select Sex</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="age">Age:</label>
                    <input type="text" id="age" name="age" placeholder="Age" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone No.:</label>
                    <input type="text" id="phone" name="phone" placeholder="###########" required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address:</label>
                    <input type="email" id="email" name="email" placeholder="Ex. juan@gmail.com" required>
                </div>
                
                <div class="form-group">
                    <label for="attachment">Attach File (PDF/DOC):</label>
                    <input type="file" id="attachment" name="attachment" accept=".pdf,.doc,.docx" required>
                    <p id="fileName" class="file-name"></p>
                </div>

                <button type="submit">Submit Application</button>
            </form>
            <div id="output" class="output"></div>
        </div>
    </div>

</body>
</html>
