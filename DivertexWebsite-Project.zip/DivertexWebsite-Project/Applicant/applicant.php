<!DOCTYPE html>
<html>
    <head>
        <title>Applicant Portal</title>

    </head>

    <body>
        <h1>Welcome To Applicant Portal!!</h1>
    </body>

</hmtl>