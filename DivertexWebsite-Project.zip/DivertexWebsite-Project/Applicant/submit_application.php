<?php
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = $_POST['name'];
    $sex = $_POST['sex'];
    $age = $_POST['age'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $attachment = $_FILES['attachment'];
    $fileName = $attachment['name'];
    $fileTmpName = $attachment['tmp_name'];
    $fileSize = $attachment['size'];
    $fileError = $attachment['error'];
    $fileType = $attachment['type'];

    $allowed = array('pdf', 'doc', 'docx');
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (in_array($fileExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize <= 5000000) {
                $fileNewName = uniqid('', true) . "." . $fileExt;

                $fileDestination = __DIR__ . '../uploads/' . $fileNewName;

                if (move_uploaded_file($fileTmpName, $fileDestination)) {
                    try {
                        $con = crud::connect();
                        $sql = "INSERT INTO application_form (fullName, sex, age, phone, email, applicationForm)
                                VALUES (:fullName, :sex, :age, :phone, :email, :applicationForm)";
                        $stmt = $con->prepare($sql);
                        $stmt->bindParam(':fullName', $fullName);
                        $stmt->bindParam(':sex', $sex);
                        $stmt->bindParam(':age', $age);
                        $stmt->bindParam(':phone', $phone);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':applicationForm', $fileNewName);

                        $stmt->execute();

                        // Show success message in a popup
                        echo "<script>alert('Application submitted successfully!'); window.location.href = 'applicationform.php';</script>";
                    } catch (PDOException $e) {
                        // Show error message in a popup
                        echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
                    }
                } else {
                    echo "<script>alert('Failed to move the uploaded file!');</script>";
                }
            } else {
                echo "<script>alert('Your file is too big!');</script>";
            }
        } else {
            echo "<script>alert('There was an error uploading your file!');</script>";
        }
    } else {
        echo "<script>alert('You cannot upload files of this type!');</script>";
    }
}
?>
