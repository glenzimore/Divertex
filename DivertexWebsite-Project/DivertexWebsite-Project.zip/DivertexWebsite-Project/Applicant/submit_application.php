<?php
// Include your database connection class
include '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and retrieve the form data
    $fullName = htmlspecialchars($_POST['name']);
    $sex = htmlspecialchars($_POST['sex']);
    $age = htmlspecialchars($_POST['age']);
    $phone = htmlspecialchars($_POST['phone']);
    $email = htmlspecialchars($_POST['email']);

    // Handle the file upload
    $attachment = $_FILES['attachment'];
    $uploadDir = 'uploads/'; // Ensure this directory exists and is writable
    $uploadFile = $uploadDir . basename($attachment['name']);

    // Move the uploaded file to the specified directory
    if (move_uploaded_file($attachment['tmp_name'], $uploadFile)) {
        // Prepare the SQL statement
        $con = crud::connect();
        $stmt = $con->prepare("INSERT INTO application_form (fullName, sex, age, phone, email, applicationForm) VALUES (:fullName, :sex, :age, :phone, :email, :applicationForm)");

        // Bind parameters
        $stmt->bindParam(':fullName', $fullName);
        $stmt->bindParam(':sex', $sex);
        $stmt->bindParam(':age', $age);
        $stmt->bindParam(':phone', $phone);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':applicationForm', $uploadFile);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Application submitted successfully!";
        } else {
            echo "Error submitting application.";
        }
    } else {
        echo "File upload failed.";
    }
} else {
    echo "Invalid request method.";
}
?>
